import syntaxtree.*;
import visitor.*;
import java.util.*;

public class A4 {
   public static void main(String [] args) {
      try {
         Node root = new microIRParser(System.in).Goal();
         System.out.println("Program parsed successfully");
         GJDepthFirst v = new GJDepthFirst();
         root.accept(v, root.accept(new GJDepthFirst1(), root.accept(v, null)));
         root.accept(new GJNoArguDepthFirst()); // Your assignment part is invoked here.
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
} 

